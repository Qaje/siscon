<?php

namespace App\Http\Livewire;

use Livewire\Component;

class TextureColorsController extends Component
{
    public function render()
    {
        return view('livewire.texture-colors');
    }
}
