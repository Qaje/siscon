<?php

namespace App\Http\Livewire;

use Livewire\Component;

class SoleColorsController extends Component
{
    public function render()
    {
        return view('livewire.sole-colors');
    }
}
