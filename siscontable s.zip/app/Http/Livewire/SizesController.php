<?php

namespace App\Http\Livewire;

use Livewire\Component;

class SizesController extends Component
{
    public function render()
    {
        return view('livewire.sizes');
    }
}
