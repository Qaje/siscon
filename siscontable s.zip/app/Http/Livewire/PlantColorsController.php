<?php

namespace App\Http\Livewire;

use Livewire\Component;

class PlantColorsController extends Component
{
    public function render()
    {
        return view('livewire.plant-colors');
    }
}
