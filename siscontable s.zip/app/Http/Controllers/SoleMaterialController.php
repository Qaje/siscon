<?php

namespace App\Http\Controllers;

use App\Models\Sole_Material;
use Illuminate\Http\Request;

class SoleMaterialController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Sole_Material  $sole_Material
     * @return \Illuminate\Http\Response
     */
    public function show(Sole_Material $sole_Material)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Sole_Material  $sole_Material
     * @return \Illuminate\Http\Response
     */
    public function edit(Sole_Material $sole_Material)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Sole_Material  $sole_Material
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sole_Material $sole_Material)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Sole_Material  $sole_Material
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sole_Material $sole_Material)
    {
        //
    }
}
