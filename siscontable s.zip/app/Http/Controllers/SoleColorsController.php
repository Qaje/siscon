<?php

namespace App\Http\Controllers;

use App\Models\Sole_Colors;
use Illuminate\Http\Request;

class SoleColorsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Sole_Colors  $sole_Colors
     * @return \Illuminate\Http\Response
     */
    public function show(Sole_Colors $sole_Colors)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Sole_Colors  $sole_Colors
     * @return \Illuminate\Http\Response
     */
    public function edit(Sole_Colors $sole_Colors)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Sole_Colors  $sole_Colors
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sole_Colors $sole_Colors)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Sole_Colors  $sole_Colors
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sole_Colors $sole_Colors)
    {
        //
    }
}
