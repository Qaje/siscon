<?php

namespace App\Http\Controllers;

use App\Models\Texture_Color;
use Illuminate\Http\Request;

class TextureColorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Texture_Color  $texture_Color
     * @return \Illuminate\Http\Response
     */
    public function show(Texture_Color $texture_Color)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Texture_Color  $texture_Color
     * @return \Illuminate\Http\Response
     */
    public function edit(Texture_Color $texture_Color)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Texture_Color  $texture_Color
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Texture_Color $texture_Color)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Texture_Color  $texture_Color
     * @return \Illuminate\Http\Response
     */
    public function destroy(Texture_Color $texture_Color)
    {
        //
    }
}
