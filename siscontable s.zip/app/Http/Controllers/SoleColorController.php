<?php

namespace App\Http\Controllers;

use App\Models\Sole_Color;
use Illuminate\Http\Request;

class SoleColorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Sole_Color  $sole_Color
     * @return \Illuminate\Http\Response
     */
    public function show(Sole_Color $sole_Color)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Sole_Color  $sole_Color
     * @return \Illuminate\Http\Response
     */
    public function edit(Sole_Color $sole_Color)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Sole_Color  $sole_Color
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sole_Color $sole_Color)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Sole_Color  $sole_Color
     * @return \Illuminate\Http\Response
     */
    public function destroy(Sole_Color $sole_Color)
    {
        //
    }
}
